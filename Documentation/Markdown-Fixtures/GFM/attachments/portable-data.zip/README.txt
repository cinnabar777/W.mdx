Nested archive attachment sample for W.mdx phone testing.
